"""
backend/eeg_bridge.py
─────────────────────────────────────────────────────────────────
Thin JSON bridge between Electron (main.js) and your existing
Python modules (SignalWorker, ExperimentLogic, etc.).

Protocol:
  stdin  ← {"cmd": "connect"} | {"cmd": "start_baseline"} | …
  stdout → {"event": "connection_status", "data": {…}}  (one JSON per line)

Run standalone to test:
  echo '{"cmd": "connect"}' | python3 eeg_bridge.py
"""

import sys
import os
import json
import threading
import time
from datetime import datetime

# ── path setup ────────────────────────────────────────────────────────
# Adjust this to point at the root of your existing Python project
ROOT = os.path.join(os.path.dirname(__file__), '..', '..')
sys.path.insert(0, ROOT)

# ── lazy imports (keep bridge importable even without PyQt5) ──────────
try:
    from core.signal_worker import SignalWorker
    from tasks.experiment_logic import ExperimentLogic, ExperimentPhase
    HAS_BACKEND = True
except ImportError as e:
    HAS_BACKEND = False
    _import_error = str(e)


# ─────────────────────────────────────────────────────────────────────
# EMIT HELPER
# ─────────────────────────────────────────────────────────────────────
def emit(event: str, data: dict):
    """Write one NDJSON line to stdout for Electron to consume."""
    payload = json.dumps({"event": event, "data": data}, ensure_ascii=True)
    sys.stdout.write(payload + "\n")
    sys.stdout.flush()


# ─────────────────────────────────────────────────────────────────────
# BRIDGE CLASS
# ─────────────────────────────────────────────────────────────────────
class EEGBridge:
    def __init__(self):
        self.signal_worker = None
        self.experiment_logic = None
        self.is_logging = False
        self.data_log = []
        self._log_buffer = []
        self._log_counter = 0
        self._subsampling_factor = 5   # 250 Hz → 50 Hz
        self._log_buffer_size = 50
        self.current_phase = "idle"
        self.current_user = None
        self.user_folder = None
        self._phase_labels = {
            'idle': 'idle',
            'setup': 'setup',
            'baseline_eyes_open': 'baseline_eyes_open',
            'baseline_eyes_closed': 'baseline_eyes_closed',
            'baseline_completed': 'baseline_completed',
            'low_load': 'low_cognitive_load',
            'low_load_completed': 'low_load_completed',
            'high_load': 'high_cognitive_load',
            'high_load_completed': 'high_load_completed',
            'analysis': 'analysis',
            'completed': 'completed',
        }

        # Ratio polling thread
        self._ratio_thread = None
        self._ratio_running = False

    # ── CONNECT ──────────────────────────────────────────────────────
    def connect(self):
        if not HAS_BACKEND:
            emit("connection_status", {"connected": False, "message": f"Import error: {_import_error}"})
            return

        try:
            self.signal_worker = SignalWorker(sample_rate=250, n_channels=8, buffer_duration=2.0)
            self.signal_worker.connection_status.connect(self._on_connection_status)
            self.signal_worker.data_ready.connect(self._on_data_ready)
            self.signal_worker.connect_to_stream()
            if self.signal_worker.inlet:
                self.signal_worker.start()
                emit("connection_status", {"connected": True, "message": ""})
                self._start_ratio_polling()
            else:
                emit("connection_status", {"connected": False, "message": "No LSL stream found."})
        except Exception as exc:
            emit("connection_status", {"connected": False, "message": str(exc)})

    def disconnect(self):
        self._ratio_running = False
        if self.signal_worker and self.signal_worker.isRunning():
            self.signal_worker.stop()
            self.signal_worker.wait()
        emit("connection_status", {"connected": False, "message": ""})

    def _on_connection_status(self, connected, message):
        emit("connection_status", {"connected": bool(connected), "message": str(message)})

    # ── SETUP ────────────────────────────────────────────────────────
    def start_setup(self, user: str):
        self.current_user = user
        self.user_folder = f"data_{user}"
        os.makedirs(self.user_folder, exist_ok=True)
        if HAS_BACKEND:
            self.experiment_logic = ExperimentLogic()
            self.experiment_logic.phase_changed.connect(self._on_phase_changed)
            self.experiment_logic.timer_update.connect(self._on_timer_update)
            self.experiment_logic.start_setup()
        self.current_phase = "setup"
        self.is_logging = True
        self._log_counter = 0
        emit("phase_changed", {"phase": "setup", "message": ""})

    # ── BASELINE ─────────────────────────────────────────────────────
    def start_baseline(self):
        if self.experiment_logic:
            self.experiment_logic.start_baseline()
        self.current_phase = "baseline_eyes_open"
        emit("phase_changed", {"phase": "baseline_eyes_open", "message": ""})

    # ── LOW LOAD ─────────────────────────────────────────────────────
    def start_low_load(self):
        if self.experiment_logic:
            self.experiment_logic.start_low_load()
        self.current_phase = "low_load"
        emit("phase_changed", {"phase": "low_load", "message": ""})

    # ── HIGH LOAD ────────────────────────────────────────────────────
    def start_high_load(self):
        if self.experiment_logic:
            self.experiment_logic.start_high_load()
        self.current_phase = "high_load"
        emit("phase_changed", {"phase": "high_load", "message": ""})

    # ── PHASE / TIMER CALLBACKS ──────────────────────────────────────
    def _on_phase_changed(self, phase, message):
        self.current_phase = str(phase)
        emit("phase_changed", {"phase": str(phase), "message": str(message)})

    def _on_timer_update(self, time_str):
        emit("timer_update", {"time": str(time_str)})

    # ── DATA LOGGING ─────────────────────────────────────────────────
    def _on_data_ready(self, data, timestamp):
        if not self.is_logging:
            return
        self._log_counter += 1
        if self._log_counter % self._subsampling_factor != 0:
            return
        self._log_buffer.append((data, float(timestamp), self.current_phase))
        if len(self._log_buffer) >= self._log_buffer_size:
            self._flush_buffer()
        emit("sample_count", {"count": int(len(self.data_log) + len(self._log_buffer))})

    def _flush_buffer(self):
        import numpy as np
        for data, ts, phase in self._log_buffer:
            record = {
                'timestamp': ts,
                'phase': phase,
                'label': self._phase_labels.get(phase, phase),
                'channel_0': float(data[0]) if len(data) > 0 else float('nan'),
                'channel_1': float(data[1]) if len(data) > 1 else float('nan'),
                'channel_2': float(data[2]) if len(data) > 2 else float('nan'),
                'channel_3': float(data[3]) if len(data) > 3 else float('nan'),
                'channel_4': float(data[4]) if len(data) > 4 else float('nan'),
                'channel_5': float(data[5]) if len(data) > 5 else float('nan'),
                'channel_6': float(data[6]) if len(data) > 6 else float('nan'),
                'channel_7': float(data[7]) if len(data) > 7 else float('nan'),
            }
            self.data_log.append(record)
        self._log_buffer.clear()

    # ── RATIO POLLING ────────────────────────────────────────────────
    def _start_ratio_polling(self):
        self._ratio_running = True
        self._ratio_thread = threading.Thread(target=self._ratio_loop, daemon=True)
        self._ratio_thread.start()

    def _ratio_loop(self):
        while self._ratio_running:
            time.sleep(2.0)
            if self.signal_worker and self.signal_worker.isRunning():
                result = self.signal_worker.get_cognitive_load_ratio()
                if result is not None:
                    ratio, theta, alpha = result
                    emit("ratio_update", {
                        "ratio": float(ratio),
                        "theta": float(theta),
                        "alpha": float(alpha),
                    })

    # ── SAVE ─────────────────────────────────────────────────────────
    def save_data(self):
        import pandas as pd
        if self._log_buffer:
            self._flush_buffer()
        if not self.data_log:
            emit("save_error", {"error": "No data to save."})
            return
        if not self.current_user:
            emit("save_error", {"error": "No user set."})
            return
        try:
            df = pd.DataFrame(self.data_log)
            ts = datetime.now().strftime("%Y%m%d_%H%M%S")
            filename = f"eeg_data_{ts}.csv"
            filepath = os.path.join(self.user_folder, filename)
            df.to_csv(filepath, index=False)
            emit("save_done", {"rows": len(df), "filepath": filepath})
        except Exception as exc:
            emit("save_error", {"error": str(exc)})


# ─────────────────────────────────────────────────────────────────────
# STDIN COMMAND LOOP
# ─────────────────────────────────────────────────────────────────────
def main():
    bridge = EEGBridge()
    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue
        try:
            msg = json.loads(line)
        except json.JSONDecodeError:
            continue

        cmd = msg.get("cmd", "")
        if cmd == "connect":
            bridge.connect()
        elif cmd == "disconnect":
            bridge.disconnect()
        elif cmd == "start_setup":
            bridge.start_setup(msg.get("user", "unknown"))
        elif cmd == "start_baseline":
            bridge.start_baseline()
        elif cmd == "start_low_load":
            bridge.start_low_load()
        elif cmd == "start_high_load":
            bridge.start_high_load()
        elif cmd == "save_data":
            bridge.save_data()


if __name__ == "__main__":
    main()
