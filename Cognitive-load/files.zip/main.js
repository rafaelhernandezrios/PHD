/**
 * main.js — Electron entry point
 * Launches the renderer and bridges IPC calls to the Python backend.
 *
 * Structure:
 *   main.js          ← this file
 *   preload.js       ← contextBridge (security layer)
 *   index.html       ← renderer UI
 *   backend/         ← your existing Python files (signal_worker, experiment_logic, etc.)
 *
 * Install deps:
 *   npm install electron python-shell
 *
 * Run:
 *   npx electron .
 */

const { app, BrowserWindow, ipcMain, dialog } = require('electron');
const path = require('path');
const { PythonShell } = require('python-shell');

let mainWindow;
let pyShell = null;  // persistent Python process

// ─────────────────────────────────────────────────────────────────────
// WINDOW
// ─────────────────────────────────────────────────────────────────────
function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1280,
    height: 820,
    minWidth: 960,
    minHeight: 600,
    titleBarStyle: 'hidden',          // custom titlebar in HTML
    trafficLightPosition: { x: -999, y: -999 }, // hide native dots (drawn in HTML)
    backgroundColor: '#080c10',
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
    },
  });

  mainWindow.loadFile('index.html');

  // Open DevTools in dev mode
  if (process.env.NODE_ENV === 'development') {
    mainWindow.webContents.openDevTools({ mode: 'detach' });
  }
}

app.whenReady().then(createWindow);
app.on('window-all-closed', () => { if (process.platform !== 'darwin') app.quit(); });
app.on('activate', () => { if (BrowserWindow.getAllWindows().length === 0) createWindow(); });
app.on('before-quit', () => { stopPython(); });

// ─────────────────────────────────────────────────────────────────────
// PYTHON BRIDGE
// Spawns backend/eeg_bridge.py which wraps your existing modules.
// Messages are NDJSON lines (one JSON object per line).
// ─────────────────────────────────────────────────────────────────────
function startPython() {
  if (pyShell) return;

  pyShell = new PythonShell(path.join(__dirname, 'backend', 'eeg_bridge.py'), {
    mode: 'json',
    pythonPath: process.env.PYTHON_PATH || 'python3',
    pythonOptions: ['-u'],
  });

  // Python → Renderer
  pyShell.on('message', (msg) => {
    if (!mainWindow) return;
    const { event, data } = msg;
    switch (event) {
      case 'connection_status':
        mainWindow.webContents.send('connection-status', data.connected, data.message);
        break;
      case 'phase_changed':
        mainWindow.webContents.send('phase-changed', data.phase, data.message);
        break;
      case 'timer_update':
        mainWindow.webContents.send('timer-update', data.time);
        break;
      case 'ratio_update':
        mainWindow.webContents.send('ratio-update', data.ratio, data.theta, data.alpha);
        break;
      case 'sample_count':
        mainWindow.webContents.send('sample-count', data.count);
        break;
      case 'save_done':
        dialog.showMessageBox(mainWindow, {
          type: 'info',
          title: 'Data Saved',
          message: `Saved ${data.rows} rows to:\n${data.filepath}`,
        });
        break;
      case 'save_error':
        dialog.showErrorBox('Save Error', data.error);
        break;
      default:
        console.warn('[python]', msg);
    }
  });

  pyShell.on('stderr', (line) => console.error('[python stderr]', line));
  pyShell.on('error', (err) => console.error('[python error]', err));
}

function stopPython() {
  if (pyShell) { pyShell.kill(); pyShell = null; }
}

function sendToPython(cmd, payload = {}) {
  if (!pyShell) {
    console.warn('[main] Python not running — command ignored:', cmd);
    return;
  }
  pyShell.send({ cmd, ...payload });
}

// ─────────────────────────────────────────────────────────────────────
// IPC HANDLERS  (renderer → main → python)
// ─────────────────────────────────────────────────────────────────────
ipcMain.handle('connect-device', async () => {
  startPython();
  sendToPython('connect');
});

ipcMain.handle('disconnect-device', async () => {
  sendToPython('disconnect');
  stopPython();
});

ipcMain.handle('start-setup', async (_event, userId) => {
  sendToPython('start_setup', { user: userId });
});

ipcMain.handle('start-baseline', async () => {
  sendToPython('start_baseline');
});

ipcMain.handle('start-low-load', async () => {
  sendToPython('start_low_load');
});

ipcMain.handle('start-high-load', async () => {
  sendToPython('start_high_load');
});

ipcMain.handle('save-data', async () => {
  sendToPython('save_data');
});
