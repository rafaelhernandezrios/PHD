/**
 * preload.js — contextBridge security layer
 * Exposes only the needed IPC methods to the renderer.
 * Never expose ipcRenderer directly.
 */

const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('electronAPI', {
  // Renderer → Main (invoke = async request/response)
  connectDevice:    ()       => ipcRenderer.invoke('connect-device'),
  disconnectDevice: ()       => ipcRenderer.invoke('disconnect-device'),
  startSetup:       (userId) => ipcRenderer.invoke('start-setup', userId),
  startBaseline:    ()       => ipcRenderer.invoke('start-baseline'),
  startLowLoad:     ()       => ipcRenderer.invoke('start-low-load'),
  startHighLoad:    ()       => ipcRenderer.invoke('start-high-load'),
  saveData:         ()       => ipcRenderer.invoke('save-data'),

  // Main → Renderer (push events from Python)
  onConnectionStatus: (cb) => ipcRenderer.on('connection-status', (_e, ...a) => cb(...a)),
  onPhaseChanged:     (cb) => ipcRenderer.on('phase-changed',     (_e, ...a) => cb(...a)),
  onTimerUpdate:      (cb) => ipcRenderer.on('timer-update',      (_e, ...a) => cb(...a)),
  onRatioUpdate:      (cb) => ipcRenderer.on('ratio-update',      (_e, ...a) => cb(...a)),
  onSampleCount:      (cb) => ipcRenderer.on('sample-count',      (_e, ...a) => cb(...a)),
});
